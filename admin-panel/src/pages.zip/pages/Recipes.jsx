import { useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { Plus, Trash2, Calculator } from 'lucide-react'
import DashboardShell from '../components/layout/DashboardShell'
import PageHeader from '../components/layout/PageHeader'
import Card from '../components/ui/Card'
import Button from '../components/ui/Button'
import Modal from '../components/ui/Modal'
import Field from '../components/ui/Field'
import { useCursorList } from '../hooks/useCursorList'
import { listRecipes, createRecipe, calculateRecipe } from '../api/recipes'
import { listIngredients } from '../api/ingredients'
import { getApiErrorMessage } from '../api/client'

export default function Recipes() {
  const { items: recipes, isLoading, isError, hasNextPage, fetchNextPage, isFetchingNextPage } =
    useCursorList({ queryKey: ['recipes'], queryFn: listRecipes, itemsKey: 'recipes' })

  const queryClient = useQueryClient()
  const [createOpen, setCreateOpen] = useState(false)
  const [calcOpen, setCalcOpen] = useState(false)
  const [calcTarget, setCalcTarget] = useState(null)

  return (
    <DashboardShell>
      <PageHeader
        title="Recipes"
        description="Ingredient breakdowns for each product, used for nutrition and batch planning."
        action={
          <Button onClick={() => setCreateOpen(true)}>
            <Plus className="h-4 w-4" /> New recipe
          </Button>
        }
      />

      <Card className="overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-cream-200 text-ink-500">
            <tr>
              <th className="px-5 py-3 font-medium">Recipe</th>
              <th className="px-5 py-3 font-medium">Product</th>
              <th className="px-5 py-3 font-medium">Created</th>
              <th className="px-5 py-3 font-medium" />
            </tr>
          </thead>
          <tbody className="divide-y divide-cream-100">
            {recipes.map((recipe) => (
              <tr key={recipe.id} className="hover:bg-cream-50">
                <td className="px-5 py-3 font-medium text-ink-900">{recipe.name}</td>
                <td className="px-5 py-3 text-ink-700">{recipe.product_name}</td>
                <td className="px-5 py-3 text-ink-700">
                  {new Date(recipe.created_at).toLocaleDateString('en-IN')}
                </td>
                <td className="px-5 py-3 text-right">
                  <button
                    onClick={() => {
                      setCalcTarget(recipe)
                      setCalcOpen(true)
                    }}
                    className="inline-flex items-center gap-1.5 rounded-pill bg-cream-100 px-3 py-1.5 text-xs font-semibold text-ink-700 hover:bg-cream-200"
                  >
                    <Calculator className="h-3.5 w-3.5" /> Scale batch
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {isLoading ? <p className="p-6 text-center text-ink-300">Loading…</p> : null}
        {isError ? <p className="p-6 text-center text-chili-500">Couldn't load recipes.</p> : null}
        {!isLoading && recipes.length === 0 ? (
          <p className="p-6 text-center text-ink-300">No recipes yet.</p>
        ) : null}
      </Card>

      {hasNextPage ? (
        <div className="mt-4 text-center">
          <Button variant="ghost" onClick={() => fetchNextPage()} disabled={isFetchingNextPage}>
            {isFetchingNextPage ? 'Loading…' : 'Load more'}
          </Button>
        </div>
      ) : null}

      <CreateRecipeModal
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        onCreated={() => queryClient.invalidateQueries({ queryKey: ['recipes'] })}
      />

      <CalculateRecipeModal
        open={calcOpen}
        recipe={calcTarget}
        onClose={() => {
          setCalcOpen(false)
          setCalcTarget(null)
        }}
      />
    </DashboardShell>
  )
}

function CreateRecipeModal({ open, onClose, onCreated }) {
  const [productId, setProductId] = useState('')
  const [name, setName] = useState('')
  const [totalWeightG, setTotalWeightG] = useState('')
  const [rows, setRows] = useState([{ ingredient_id: '', quantity_g: '' }])
  const [error, setError] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const ingredientsQuery = useCursorList({
    queryKey: ['ingredients'],
    queryFn: listIngredients,
    itemsKey: 'ingredients',
  })

  const addRow = () => setRows((r) => [...r, { ingredient_id: '', quantity_g: '' }])
  const removeRow = (idx) => setRows((r) => r.filter((_, i) => i !== idx))
  const updateRow = (idx, field, value) =>
    setRows((r) => r.map((row, i) => (i === idx ? { ...row, [field]: value } : row)))

  const resetAndClose = () => {
    setProductId('')
    setName('')
    setTotalWeightG('')
    setRows([{ ingredient_id: '', quantity_g: '' }])
    setError(null)
    onClose()
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError(null)

    const validRows = rows.filter((r) => r.ingredient_id && r.quantity_g)
    if (validRows.length === 0) {
      setError('Add at least one ingredient with a quantity.')
      return
    }

    setIsSubmitting(true)
    try {
      const data = await createRecipe({
        product_id: Number(productId),
        name,
        total_weight_g: Number(totalWeightG),
        ingredients: validRows.map((r) => ({
          ingredient_id: Number(r.ingredient_id),
          quantity_g: Number(r.quantity_g),
        })),
      })
      if (data.success) {
        onCreated()
        resetAndClose()
      } else {
        setError(data.message || 'Could not create recipe')
      }
    } catch (err) {
      setError(getApiErrorMessage(err, 'Could not create recipe'))
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Modal open={open} onClose={resetAndClose} title="New recipe" maxWidth="max-w-2xl">
      <form onSubmit={handleSubmit} className="space-y-4">
        <Field
          label="Product ID"
          type="number"
          value={productId}
          onChange={(e) => setProductId(e.target.value)}
          hint="The ID of the product this recipe belongs to (see Products page)."
          required
        />
        <Field label="Recipe name" value={name} onChange={(e) => setName(e.target.value)} required />
        <Field
          label="Total weight (g)"
          type="number"
          step="0.01"
          value={totalWeightG}
          onChange={(e) => setTotalWeightG(e.target.value)}
          hint="Total weight this recipe produces — used to scale nutrition per product unit."
          required
        />

        <div>
          <p className="mb-1.5 text-sm font-medium text-ink-700">Ingredients</p>
          <div className="space-y-2">
            {rows.map((row, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <select
                  value={row.ingredient_id}
                  onChange={(e) => updateRow(idx, 'ingredient_id', e.target.value)}
                  className="flex-1 rounded-xl border border-cream-300 bg-white px-3 py-2 text-sm outline-none focus:border-chili-400"
                >
                  <option value="">Select ingredient…</option>
                  {ingredientsQuery.items.map((ing) => (
                    <option key={ing.id} value={ing.id}>
                      {ing.name}
                    </option>
                  ))}
                </select>
                <input
                  type="number"
                  step="0.01"
                  placeholder="grams"
                  value={row.quantity_g}
                  onChange={(e) => updateRow(idx, 'quantity_g', e.target.value)}
                  className="w-28 rounded-xl border border-cream-300 bg-white px-3 py-2 text-sm outline-none focus:border-chili-400"
                />
                <button
                  type="button"
                  onClick={() => removeRow(idx)}
                  className="rounded-full p-2 text-ink-300 hover:bg-cream-100 hover:text-chili-500"
                  aria-label="Remove ingredient"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>
          <button
            type="button"
            onClick={addRow}
            className="mt-2 text-sm font-medium text-chili-500"
          >
            + Add ingredient
          </button>
        </div>

        {error ? <p className="text-sm font-medium text-chili-500">{error}</p> : null}

        <Button type="submit" loading={isSubmitting} className="w-full">
          Create recipe
        </Button>
      </form>
    </Modal>
  )
}

function CalculateRecipeModal({ open, recipe, onClose }) {
  const [requiredKg, setRequiredKg] = useState('')
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [isLoading, setIsLoading] = useState(false)

  const handleCalculate = async (e) => {
    e.preventDefault()
    setError(null)
    setResult(null)
    setIsLoading(true)
    try {
      const data = await calculateRecipe({
        recipe_id: recipe.id,
        required_quantity_kg: Number(requiredKg),
      })
      if (data.success) {
        setResult(data)
      } else {
        setError(data.message || 'Could not calculate')
      }
    } catch (err) {
      setError(getApiErrorMessage(err, 'Could not calculate'))
    } finally {
      setIsLoading(false)
    }
  }

  const handleClose = () => {
    setRequiredKg('')
    setResult(null)
    setError(null)
    onClose()
  }

  if (!recipe) return null

  return (
    <Modal open={open} onClose={handleClose} title={`Scale "${recipe.name}" for batch production`}>
      <form onSubmit={handleCalculate} className="space-y-4">
        <Field
          label="Required quantity (kg)"
          type="number"
          step="0.01"
          value={requiredKg}
          onChange={(e) => setRequiredKg(e.target.value)}
          hint="How many kg of this product do you need to produce?"
          required
        />

        {error ? <p className="text-sm font-medium text-chili-500">{error}</p> : null}

        <Button type="submit" loading={isLoading} className="w-full">
          Calculate
        </Button>
      </form>

      {result ? (
        <div className="mt-5 border-t border-cream-200 pt-4">
          <p className="text-sm font-medium text-ink-700">
            Ingredients needed for {result.required_quantity_kg} kg:
          </p>
          <div className="mt-2 space-y-1.5">
            {result.ingredients.map((ing) => (
              <div
                key={ing.ingredient_id}
                className="flex items-center justify-between rounded-xl bg-cream-100 px-3 py-2 text-sm"
              >
                <span className="text-ink-700">{ing.ingredient_name}</span>
                <span className="font-semibold text-ink-900">{ing.display_quantity}</span>
              </div>
            ))}
          </div>
        </div>
      ) : null}
    </Modal>
  )
}
