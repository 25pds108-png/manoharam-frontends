import { useState } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { Plus } from 'lucide-react'
import DashboardShell from '../components/layout/DashboardShell'
import PageHeader from '../components/layout/PageHeader'
import Card from '../components/ui/Card'
import Button from '../components/ui/Button'
import Badge, { toneForStatus, formatStatusLabel } from '../components/ui/Badge'
import Modal from '../components/ui/Modal'
import Field from '../components/ui/Field'
import { useCursorList } from '../hooks/useCursorList'
import { listProducts, createProduct } from '../api/products'
import { getApiErrorMessage } from '../api/client'

const emptyForm = {
  name: '',
  category: '',
  quantity: '',
  unit: 'g',
  selling_price: '',
  description: '',
  image_url: '',
  status: 'ACTIVE',
}

export default function Products() {
  const { items: products, isLoading, isError, hasNextPage, fetchNextPage, isFetchingNextPage } =
    useCursorList({ queryKey: ['products'], queryFn: listProducts, itemsKey: 'products' })

  const queryClient = useQueryClient()
  const [modalOpen, setModalOpen] = useState(false)
  const [form, setForm] = useState(emptyForm)
  const [error, setError] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const update = (field) => (e) => setForm((prev) => ({ ...prev, [field]: e.target.value }))

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError(null)
    setIsSubmitting(true)
    try {
      const data = await createProduct({
        ...form,
        quantity: Number(form.quantity),
        selling_price: Number(form.selling_price),
      })
      if (data.success) {
        queryClient.invalidateQueries({ queryKey: ['products'] })
        setModalOpen(false)
        setForm(emptyForm)
      } else {
        setError(data.message || 'Could not create product')
      }
    } catch (err) {
      setError(getApiErrorMessage(err, 'Could not create product'))
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <DashboardShell>
      <PageHeader
        title="Products"
        description="Items shown on the storefront menu."
        action={
          <Button onClick={() => setModalOpen(true)}>
            <Plus className="h-4 w-4" /> New product
          </Button>
        }
      />

      <Card className="overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-cream-200 text-ink-500">
            <tr>
              <th className="px-5 py-3 font-medium">Product</th>
              <th className="px-5 py-3 font-medium">Category</th>
              <th className="px-5 py-3 font-medium">Price</th>
              <th className="px-5 py-3 font-medium">Qty / Unit</th>
              <th className="px-5 py-3 font-medium">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-cream-100">
            {products.map((product) => (
              <tr key={product.id} className="hover:bg-cream-50">
                <td className="px-5 py-3">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 shrink-0 overflow-hidden rounded-lg bg-cream-200">
                      {product.image_url ? (
                        <img
                          src={product.image_url}
                          alt={product.name}
                          className="h-full w-full object-cover"
                        />
                      ) : null}
                    </div>
                    <span className="font-medium text-ink-900">{product.name}</span>
                  </div>
                </td>
                <td className="px-5 py-3 text-ink-700">{product.category || '—'}</td>
                <td className="px-5 py-3 font-medium text-ink-900">
                  ₹{Number(product.selling_price).toFixed(0)}
                </td>
                <td className="px-5 py-3 text-ink-700">
                  {product.quantity} {product.unit}
                </td>
                <td className="px-5 py-3">
                  <Badge tone={toneForStatus(product.status)}>
                    {formatStatusLabel(product.status)}
                  </Badge>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {isLoading ? <p className="p-6 text-center text-ink-300">Loading…</p> : null}
        {isError ? (
          <p className="p-6 text-center text-chili-500">Couldn't load products.</p>
        ) : null}
        {!isLoading && products.length === 0 ? (
          <p className="p-6 text-center text-ink-300">No products yet.</p>
        ) : null}
      </Card>

      {hasNextPage ? (
        <div className="mt-4 text-center">
          <Button variant="ghost" onClick={() => fetchNextPage()} disabled={isFetchingNextPage}>
            {isFetchingNextPage ? 'Loading…' : 'Load more'}
          </Button>
        </div>
      ) : null}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="New product">
        <form onSubmit={handleSubmit} className="space-y-4">
          <Field label="Name" value={form.name} onChange={update('name')} required />
          <Field label="Category" value={form.category} onChange={update('category')} />

          <div className="grid grid-cols-2 gap-3">
            <Field
              label="Quantity"
              type="number"
              step="0.01"
              value={form.quantity}
              onChange={update('quantity')}
              required
            />
            <Field as="select" label="Unit" value={form.unit} onChange={update('unit')}>
              <option value="g">g</option>
              <option value="kg">kg</option>
            </Field>
          </div>

          <Field
            label="Selling price (₹)"
            type="number"
            step="0.01"
            value={form.selling_price}
            onChange={update('selling_price')}
            required
          />

          <Field as="textarea" rows={3} label="Description" value={form.description} onChange={update('description')} />
          <Field label="Image URL" value={form.image_url} onChange={update('image_url')} />

          <Field as="select" label="Status" value={form.status} onChange={update('status')}>
            <option value="ACTIVE">Active</option>
            <option value="INACTIVE">Inactive</option>
          </Field>

          {error ? <p className="text-sm font-medium text-chili-500">{error}</p> : null}

          <Button type="submit" loading={isSubmitting} className="w-full">
            Create product
          </Button>
        </form>
      </Modal>
    </DashboardShell>
  )
}
