import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { ClipboardList, CalendarCheck, AlertCircle } from 'lucide-react'
import DashboardShell from '../components/layout/DashboardShell'
import PageHeader from '../components/layout/PageHeader'
import Card from '../components/ui/Card'
import Badge, { toneForStatus, formatStatusLabel } from '../components/ui/Badge'
import { listOrders } from '../api/orders'
import { listSubscriptions } from '../api/subscriptions'

export default function Dashboard() {
  const ordersQuery = useQuery({
    queryKey: ['orders', 'recent'],
    queryFn: () => listOrders({ limit: 50 }),
  })

  const subscriptionsQuery = useQuery({
    queryKey: ['subscriptions', 'recent'],
    queryFn: () => listSubscriptions({ limit: 50 }),
  })

  const orders = ordersQuery.data?.orders ?? []
  const subscriptions = subscriptionsQuery.data?.subscriptions ?? []

  const pendingOrders = orders.filter((o) => o.status === 'PENDING')
  const pendingSubscriptions = subscriptions.filter((s) => s.status === 'PENDING')
  const revenueToday = orders
    .filter((o) => {
      const d = new Date(o.order_date)
      const today = new Date()
      return (
        d.getDate() === today.getDate() &&
        d.getMonth() === today.getMonth() &&
        d.getFullYear() === today.getFullYear() &&
        o.status !== 'CANCELLED'
      )
    })
    .reduce((sum, o) => sum + Number(o.total_amount), 0)

  return (
    <DashboardShell>
      <PageHeader title="Dashboard" description="Here's what's happening today." />

      <div className="grid grid-cols-3 gap-4">
        <Card className="p-5">
          <p className="text-sm text-ink-500">Orders awaiting confirmation</p>
          <p className="mt-2 font-display text-3xl font-semibold text-ink-900">
            {pendingOrders.length}
          </p>
        </Card>
        <Card className="p-5">
          <p className="text-sm text-ink-500">Subscriptions awaiting approval</p>
          <p className="mt-2 font-display text-3xl font-semibold text-ink-900">
            {pendingSubscriptions.length}
          </p>
        </Card>
        <Card className="p-5">
          <p className="text-sm text-ink-500">Revenue today</p>
          <p className="mt-2 font-display text-3xl font-semibold text-chili-500">
            ₹{revenueToday.toFixed(0)}
          </p>
        </Card>
      </div>

      <div className="mt-8 grid grid-cols-2 gap-6">
        <Card className="p-5">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-semibold text-ink-900">
              Orders needing attention
            </h2>
            <Link to="/orders" className="text-sm font-medium text-chili-500">
              View all
            </Link>
          </div>

          {ordersQuery.isLoading ? <p className="mt-4 text-sm text-ink-300">Loading…</p> : null}

          {!ordersQuery.isLoading && pendingOrders.length === 0 ? (
            <p className="mt-4 text-sm text-ink-300">Nothing pending — nice and clear.</p>
          ) : null}

          <div className="mt-3 space-y-2">
            {pendingOrders.slice(0, 5).map((order) => (
              <Link
                key={order.id}
                to={`/orders/${order.id}`}
                className="flex items-center justify-between rounded-xl px-3 py-2.5 hover:bg-cream-100"
              >
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-4 w-4 text-warning-500" />
                  <span className="text-sm text-ink-900">
                    Order #{order.id} — {order.customer_name}
                  </span>
                </div>
                <span className="text-sm font-semibold text-ink-900">
                  ₹{Number(order.total_amount).toFixed(0)}
                </span>
              </Link>
            ))}
          </div>
        </Card>

        <Card className="p-5">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-base font-semibold text-ink-900">
              Subscriptions awaiting approval
            </h2>
            <Link to="/subscriptions" className="text-sm font-medium text-chili-500">
              View all
            </Link>
          </div>

          {subscriptionsQuery.isLoading ? (
            <p className="mt-4 text-sm text-ink-300">Loading…</p>
          ) : null}

          {!subscriptionsQuery.isLoading && pendingSubscriptions.length === 0 ? (
            <p className="mt-4 text-sm text-ink-300">Nothing pending.</p>
          ) : null}

          <div className="mt-3 space-y-2">
            {pendingSubscriptions.slice(0, 5).map((sub) => (
              <Link
                key={sub.id}
                to={`/subscriptions/${sub.id}`}
                className="flex items-center justify-between rounded-xl px-3 py-2.5 hover:bg-cream-100"
              >
                <div className="flex items-center gap-2">
                  <CalendarCheck className="h-4 w-4 text-warning-500" />
                  <span className="text-sm text-ink-900">
                    {sub.customer_name} — {sub.plan_name}
                  </span>
                </div>
                <Badge tone={toneForStatus(sub.status)}>{formatStatusLabel(sub.status)}</Badge>
              </Link>
            ))}
          </div>
        </Card>
      </div>
    </DashboardShell>
  )
}
