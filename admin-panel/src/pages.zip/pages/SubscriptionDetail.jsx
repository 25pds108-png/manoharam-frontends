import { useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { ChevronLeft } from 'lucide-react'
import DashboardShell from '../components/layout/DashboardShell'
import Card from '../components/ui/Card'
import Button from '../components/ui/Button'
import Badge, { toneForStatus, formatStatusLabel } from '../components/ui/Badge'
import {
  getSubscriptionDetails,
  approveSubscription,
  updateSubscription,
} from '../api/subscriptions'
import { getApiErrorMessage } from '../api/client'

// Mirrors update_subscription.php's $allowedStatuses.
const STATUS_OPTIONS = ['PENDING', 'ACTIVE', 'COMPLETED', 'CANCELLED']

export default function SubscriptionDetail() {
  const { id } = useParams()
  const navigate = useNavigate()
  const queryClient = useQueryClient()

  const { data, isLoading, isError } = useQuery({
    queryKey: ['subscription', id],
    queryFn: () => getSubscriptionDetails(id),
  })

  const [pendingStatus, setPendingStatus] = useState('')
  const [error, setError] = useState(null)
  const [isApproving, setIsApproving] = useState(false)
  const [isUpdating, setIsUpdating] = useState(false)

  const subscription = data?.subscription

  const refresh = () => {
    queryClient.invalidateQueries({ queryKey: ['subscription', id] })
    queryClient.invalidateQueries({ queryKey: ['subscriptions'] })
  }

  const handleApprove = async () => {
    setError(null)
    setIsApproving(true)
    try {
      const result = await approveSubscription(id)
      if (result.success) {
        refresh()
      } else {
        setError(result.message || 'Could not approve subscription')
      }
    } catch (err) {
      setError(getApiErrorMessage(err, 'Could not approve subscription'))
    } finally {
      setIsApproving(false)
    }
  }

  const handleUpdateStatus = async () => {
    if (!pendingStatus) return
    setError(null)
    setIsUpdating(true)
    try {
      const result = await updateSubscription({ subscriptionId: id, status: pendingStatus })
      if (result.success) {
        refresh()
        setPendingStatus('')
      } else {
        setError(result.message || 'Could not update subscription')
      }
    } catch (err) {
      setError(getApiErrorMessage(err, 'Could not update subscription'))
    } finally {
      setIsUpdating(false)
    }
  }

  if (isLoading) {
    return (
      <DashboardShell>
        <p className="text-center text-ink-300">Loading…</p>
      </DashboardShell>
    )
  }

  if (isError || !subscription) {
    return (
      <DashboardShell>
        <p className="text-center text-chili-500">Couldn't load this subscription.</p>
      </DashboardShell>
    )
  }

  return (
    <DashboardShell>
      <button
        onClick={() => navigate('/subscriptions')}
        className="mb-4 flex items-center gap-1.5 text-sm font-medium text-ink-500 hover:text-ink-900"
      >
        <ChevronLeft className="h-4 w-4" /> Back to subscriptions
      </button>

      <div className="grid grid-cols-3 gap-6">
        <div className="col-span-2 space-y-6">
          <Card className="p-5">
            <div className="flex items-center justify-between">
              <h1 className="font-display text-xl font-semibold text-ink-900">
                Subscription #{subscription.id}
              </h1>
              <Badge tone={toneForStatus(subscription.status)}>
                {formatStatusLabel(subscription.status)}
              </Badge>
            </div>
            <p className="mt-1 text-sm text-ink-500">
              {subscription.start_date} – {subscription.end_date}
            </p>
          </Card>

          <Card className="p-5">
            <h2 className="font-display text-base font-semibold text-ink-900">Plan</h2>
            <p className="mt-2 text-sm text-ink-900">{subscription.plan.name}</p>
            <p className="text-sm text-ink-500">
              {subscription.plan.duration_days} days · ₹{subscription.plan.daily_rate}/day · ₹
              {subscription.plan.price} total
            </p>
            {subscription.plan.description ? (
              <p className="mt-2 text-sm text-ink-500">{subscription.plan.description}</p>
            ) : null}
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="p-5">
            <h2 className="font-display text-base font-semibold text-ink-900">Customer</h2>
            <p className="mt-2 text-sm text-ink-900">{subscription.customer.name}</p>
            <p className="text-sm text-ink-500">{subscription.customer.email}</p>
            <p className="text-sm text-ink-500">{subscription.customer.phone}</p>
            {subscription.customer.address ? (
              <p className="mt-2 text-sm text-ink-500">{subscription.customer.address}</p>
            ) : null}
          </Card>

          <Card className="p-5">
            <h2 className="font-display text-base font-semibold text-ink-900">Actions</h2>

            {error ? <p className="mt-2 text-sm font-medium text-chili-500">{error}</p> : null}

            {subscription.status === 'PENDING' ? (
              <Button onClick={handleApprove} loading={isApproving} className="mt-3 w-full">
                Approve subscription
              </Button>
            ) : null}

            <p className="mt-4 text-xs font-medium text-ink-500">Or set a specific status</p>
            <select
              value={pendingStatus}
              onChange={(e) => setPendingStatus(e.target.value)}
              className="mt-2 w-full rounded-xl border border-cream-300 bg-white px-3.5 py-2.5 text-sm outline-none focus:border-chili-400"
            >
              <option value="">Select status…</option>
              {STATUS_OPTIONS.map((s) => (
                <option key={s} value={s}>
                  {formatStatusLabel(s)}
                </option>
              ))}
            </select>
            <Button
              variant="ghost"
              onClick={handleUpdateStatus}
              loading={isUpdating}
              disabled={!pendingStatus}
              className="mt-3 w-full"
            >
              Update status
            </Button>
          </Card>
        </div>
      </div>
    </DashboardShell>
  )
}
