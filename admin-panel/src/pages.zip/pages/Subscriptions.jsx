import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useQueryClient } from '@tanstack/react-query'
import { Plus } from 'lucide-react'
import DashboardShell from '../components/layout/DashboardShell'
import PageHeader from '../components/layout/PageHeader'
import Card from '../components/ui/Card'
import Button from '../components/ui/Button'
import Badge, { toneForStatus, formatStatusLabel } from '../components/ui/Badge'
import Modal from '../components/ui/Modal'
import Field from '../components/ui/Field'
import { useCursorList } from '../hooks/useCursorList'
import { listSubscriptions, createSubscriptionPlan } from '../api/subscriptions'
import { getApiErrorMessage } from '../api/client'

const emptyPlanForm = { name: '', duration_days: '', price: '', description: '', status: 'ACTIVE' }

export default function Subscriptions() {
  const { items: subscriptions, isLoading, isError, hasNextPage, fetchNextPage, isFetchingNextPage } =
    useCursorList({
      queryKey: ['subscriptions'],
      queryFn: listSubscriptions,
      itemsKey: 'subscriptions',
    })

  const queryClient = useQueryClient()
  const [planModalOpen, setPlanModalOpen] = useState(false)
  const [planForm, setPlanForm] = useState(emptyPlanForm)
  const [error, setError] = useState(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  const updatePlanField = (field) => (e) =>
    setPlanForm((prev) => ({ ...prev, [field]: e.target.value }))

  const handleCreatePlan = async (e) => {
    e.preventDefault()
    setError(null)
    setIsSubmitting(true)
    try {
      const data = await createSubscriptionPlan({
        ...planForm,
        duration_days: Number(planForm.duration_days),
        price: Number(planForm.price),
      })
      if (data.success) {
        setPlanModalOpen(false)
        setPlanForm(emptyPlanForm)
      } else {
        setError(data.message || 'Could not create plan')
      }
    } catch (err) {
      setError(getApiErrorMessage(err, 'Could not create plan'))
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <DashboardShell>
      <PageHeader
        title="Subscriptions"
        description="Customer daily-salad subscriptions."
        action={
          <Button onClick={() => setPlanModalOpen(true)}>
            <Plus className="h-4 w-4" /> New plan
          </Button>
        }
      />

      <Card className="overflow-hidden">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-cream-200 text-ink-500">
            <tr>
              <th className="px-5 py-3 font-medium">Customer</th>
              <th className="px-5 py-3 font-medium">Plan</th>
              <th className="px-5 py-3 font-medium">Dates</th>
              <th className="px-5 py-3 font-medium">Status</th>
              <th className="px-5 py-3 font-medium" />
            </tr>
          </thead>
          <tbody className="divide-y divide-cream-100">
            {subscriptions.map((sub) => (
              <tr key={sub.id} className="hover:bg-cream-50">
                <td className="px-5 py-3">
                  <p className="font-medium text-ink-900">{sub.customer_name}</p>
                  <p className="text-xs text-ink-300">{sub.phone}</p>
                </td>
                <td className="px-5 py-3 text-ink-700">{sub.plan_name}</td>
                <td className="px-5 py-3 text-ink-700">
                  {sub.start_date} – {sub.end_date}
                </td>
                <td className="px-5 py-3">
                  <Badge tone={toneForStatus(sub.status)}>{formatStatusLabel(sub.status)}</Badge>
                </td>
                <td className="px-5 py-3 text-right">
                  <Link to={`/subscriptions/${sub.id}`} className="text-sm font-medium text-chili-500">
                    View
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {isLoading ? <p className="p-6 text-center text-ink-300">Loading…</p> : null}
        {isError ? (
          <p className="p-6 text-center text-chili-500">Couldn't load subscriptions.</p>
        ) : null}
        {!isLoading && subscriptions.length === 0 ? (
          <p className="p-6 text-center text-ink-300">No subscriptions yet.</p>
        ) : null}
      </Card>

      {hasNextPage ? (
        <div className="mt-4 text-center">
          <Button variant="ghost" onClick={() => fetchNextPage()} disabled={isFetchingNextPage}>
            {isFetchingNextPage ? 'Loading…' : 'Load more'}
          </Button>
        </div>
      ) : null}

      <Modal open={planModalOpen} onClose={() => setPlanModalOpen(false)} title="New subscription plan">
        <form onSubmit={handleCreatePlan} className="space-y-4">
          <Field label="Plan name" value={planForm.name} onChange={updatePlanField('name')} required />
          <Field
            label="Duration (days)"
            type="number"
            value={planForm.duration_days}
            onChange={updatePlanField('duration_days')}
            required
          />
          <Field
            label="Price (₹)"
            type="number"
            step="0.01"
            value={planForm.price}
            onChange={updatePlanField('price')}
            hint="Daily rate is calculated automatically as price ÷ duration."
            required
          />
          <Field
            as="textarea"
            rows={3}
            label="Description"
            value={planForm.description}
            onChange={updatePlanField('description')}
          />
          <Field as="select" label="Status" value={planForm.status} onChange={updatePlanField('status')}>
            <option value="ACTIVE">Active</option>
            <option value="INACTIVE">Inactive</option>
          </Field>

          {error ? <p className="text-sm font-medium text-chili-500">{error}</p> : null}

          <Button type="submit" loading={isSubmitting} className="w-full">
            Create plan
          </Button>
        </form>
      </Modal>
    </DashboardShell>
  )
}
