import axios from 'axios'

export const TOKEN_KEY = 'manoharam_admin_token'

export const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
})

api.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_KEY)
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

let onUnauthorized = null
export function setOnUnauthorized(fn) {
  onUnauthorized = fn
}

api.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error?.response?.status
    // admin_middleware.php returns 401 (bad/missing/expired token) or
    // 403 (valid token, but not an ADMIN role) — both should kick back to login.
    if ((status === 401 || status === 403) && onUnauthorized) {
      onUnauthorized()
    }
    return Promise.reject(error)
  }
)

export function getApiErrorMessage(error, fallback = 'Something went wrong. Please try again.') {
  return error?.response?.data?.message || error?.message || fallback
}
