import { api } from './client'

/**
 * GET /list_all_subscriptions.php?cursor=&limit=
 * Admin only.
 */
export function listSubscriptions({ cursor, limit = 20 } = {}) {
  return api
    .get('admin_routes/list_all_subscriptions.php', { params: { cursor, limit } })
    .then((res) => res.data)
}

/**
 * GET /get_subscription_details.php?id=
 * Admin only.
 */
export function getSubscriptionDetails(id) {
  return api.get('admin_routes/get_subscription_details.php', { params: { id } }).then((res) => res.data)
}

/**
 * POST /approve_subscription.php
 * Body: { subscription_id }
 * Admin only.
 *
 * NOTE: this endpoint's PHP file currently does
 *   require_once "../auth/admin_middleware";
 * missing the .php extension — it will fatal-error server-side until fixed.
 * Flag to your backend dev; the call below is correct once that's patched.
 */
export function approveSubscription(subscriptionId) {
  return api
    .post('admin_routes/approve_subscription.php', { subscription_id: subscriptionId })
    .then((res) => res.data)
}

/**
 * POST /update_subscription.php
 * Body: { subscription_id, start_date?, end_date?, status? }
 * status must be one of: PENDING, ACTIVE, COMPLETED, CANCELLED
 * Admin only.
 */
export function updateSubscription({ subscriptionId, startDate, endDate, status }) {
  return api
    .post('/update_subscription.php', {
      subscription_id: subscriptionId,
      start_date: startDate,
      end_date: endDate,
      status,
    })
    .then((res) => res.data)
}

/**
 * POST /create_subscription.php
 * Body: { name, duration_days, price, description, status }
 * This creates a SUBSCRIPTION PLAN (e.g. "Daily Salad — 30 days"), not a
 * customer's subscription. Naming is a little confusing in the backend —
 * customer subscriptions are handled by subscribe_plan.php (storefront).
 * Admin only.
 */
export function createSubscriptionPlan(payload) {
  return api.post('admin_routes/create_subscription.php', payload).then((res) => res.data)
}
