import { api } from './client'

/**
 * GET /list_all_products.php?cursor=&limit=
 * Public endpoint, but works fine for the admin product list too.
 * NOTE: there is no admin-specific "list all products including INACTIVE"
 * endpoint — this one filters to status = 'ACTIVE' only inside the PHP,
 * so inactive products won't show here either. Flag for backend: a real
 * admin product list should show every status.
 */
export function listProducts({ cursor, limit = 20 } = {}) {
  return api
    .get('/list_all_products.php', { params: { cursor, limit } })
    .then((res) => res.data)
}

/**
 * POST /create_product.php
 * Body: { name, category, quantity, unit, selling_price, description, image_url, status }
 * Admin only.
 */
export function createProduct(payload) {
  return api.post('admin_routes/create_product.php', payload).then((res) => res.data)
}

/**
 * GET /product_details.php?id=
 * Public endpoint, reused here for the admin product detail view.
 */
export function getProductDetails(id) {
  return api.get('admin_routes/product_details.php', { params: { id } }).then((res) => res.data)
}
